import { Component, OnInit, Input } from '@angular/core';

export interface Dashboard {
  name : string;
  tiles : Tile[][];
}

export interface Tile {
  name : string;
  img : string;
  time_range : '24hours' | 'week' | 'month';
  type : 'line chart' | 'bar chart' | 'pie chart';
}

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  @Input() name: string;
  selectedValue: any;

  dashboard : Dashboard = {
    name : 'Test',
    tiles : [
      [
        {
          name : 'Test-1',
          type : 'line chart',
          time_range : '24hours',
          img : 'https://via.placeholder.com/200x100'
        }
      ],
      [
        {
          name : 'Test-2',
          type : 'bar chart',
          time_range : 'week',
          img : 'https://via.placeholder.com/200x100'
        },
        {
          name : 'Test-3',
          type : 'bar chart',
          time_range : 'week',
          img : 'https://via.placeholder.com/200x100'
        }
      ],
      [
        {
          name : 'Test-4',
          type : 'pie chart',
          time_range : 'month',
          img : 'https://via.placeholder.com/200x100'
        },
        {
          name : 'Test-5',
          type : 'bar chart',
          time_range : 'month',
          img : 'https://via.placeholder.com/200x100'
        },
        {
          name : 'Test-6',
          type : 'bar chart',
          time_range : 'month',
          img : 'https://via.placeholder.com/200x100'
        }
      ]
    ]
  };
  displayParameter: any;

  constructor() { }

  // private _prevSelected: any;

  handleChange(evt){
    this.displayParameter = evt;
    console.log(evt);
  }

  // ------------------------------------------------------------------------------
  // ----------------Modal start---------------------------------------------------
  showModal : boolean;
  currentTile : any;
  // currentType : Object;
  // abc : any;
  onClick(_tile: any)
  {

    // debugger;
    this.currentTile = _tile;
    console.log(this.currentTile.type);
    console.log(this.currentTile.time_range);
    this.onCheck(this.currentTile.type);
    this.onCheck(this.currentTile.time_range);
    this.showModal = true; // Show-Hide Modal Check
    this.currentTile = _tile;

  }

 onCheck(_checkedval: string)
 {
   // debugger;
   let element = <HTMLInputElement> document.getElementById("customRadio1");
   element.checked = true;
 }

  //Bootstrap Modal Close event
  hide()
  {
    this.showModal = false;
    this.currentTile = null;
  }
  // ----------------Modal end---------------------------------------------------


  getData(){
    console.log(this.dashboard);
  }
  show(dashboard : Dashboard ) {
      this.dashboard = dashboard;
    }

  ngOnInit() {
    console.log(this.dashboard.tiles);
    this.getData();
  }

}
